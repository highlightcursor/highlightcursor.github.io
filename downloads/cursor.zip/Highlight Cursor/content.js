// Function to manage the custom highlight element
function manageCustomHighlight(size, isEnabled) {
    let customHighlight = document.getElementById('highlight-cursor-custom');
    let hideNativeCursorStyle = document.getElementById('highlight-cursor-hide-native');

    if (!isEnabled || size <= 10) { // If disabled or size is very small, remove the highlight
        if (customHighlight) {
            customHighlight.remove();
        }
        if (hideNativeCursorStyle) {
            hideNativeCursorStyle.remove();
        }
        return; // Stop here, no custom highlight needed
    }

    // Create custom highlight if it doesn't exist
    if (!customHighlight) {
        customHighlight = document.createElement('div');
        customHighlight.id = 'highlight-cursor-custom';
        customHighlight.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            background-color: rgba(79, 70, 229, 0.7); /* Semi-transparent indigo */
            border: 2px solid rgba(165, 180, 252, 0.9); /* Lighter border */
            border-radius: 50%; /* Make it circular */
            pointer-events: none; /* Crucial: allows clicks to pass through */
            z-index: 9999; /* Ensure it's on top of almost everything */
            transform: translate(-50%, -50%); /* Center the highlight on mouse position */
            transition: width 0.1s ease-out, height 0.1s ease-out; /* Smooth size transition */
            box-shadow: 0 0 10px rgba(79, 70, 229, 0.5); /* Soft glow effect */
        `;
        document.body.appendChild(customHighlight);

        // Add mousemove listener only once to track mouse position for highlight
        document.addEventListener('mousemove', (e) => {
            customHighlight.style.left = `${e.clientX}px`;
            customHighlight.style.top = `${e.clientY}px`;
        });
    }

    // Hide native cursor if style doesn't exist
    if (!hideNativeCursorStyle) {
        hideNativeCursorStyle = document.createElement('style');
        hideNativeCursorStyle.id = 'highlight-cursor-hide-native';
        document.head.appendChild(hideNativeCursorStyle);
        hideNativeCursorStyle.textContent = `
            * {
                cursor: none !important;
            }
            html {
                cursor: none !important;
            }
        `;
    }

    // Update the size of the custom highlight
    customHighlight.style.width = `${size}px`;
    customHighlight.style.height = `${size}px`;
}

// Listen for messages from the popup or background script
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.type === 'updateHighlightSize' || request.type === 'updateHighlightState') {
        // Use the size from the request, but default to current slider value if only state is updated
        const sizeToUse = request.size;
        const isEnabledToUse = request.isEnabled;
        manageCustomHighlight(sizeToUse, isEnabledToUse);
    }
});

// Load initial highlight state and size from storage when the content script runs on page load
chrome.storage.local.get(['highlightSize', 'highlightEnabled'], function(result) {
    const initialSize = result.highlightSize || 32;
    const initialEnabled = result.highlightEnabled !== undefined ? result.highlightEnabled : true; // Default to enabled
    manageCustomHighlight(initialSize, initialEnabled);
});
