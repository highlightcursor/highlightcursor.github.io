document.addEventListener('DOMContentLoaded', function() {
    const highlightSizeSlider = document.getElementById('highlightSize');
    const currentSizeDisplay = document.getElementById('currentSize');
    const highlightToggle = document.getElementById('highlightToggle'); // New toggle switch

    // Function to send message to content script
    function sendMessageToContent(type, size, isEnabled) {
        chrome.tabs.query({}, function(tabs) {
            tabs.forEach(function(tab) {
                if (tab.id) {
                    chrome.tabs.sendMessage(tab.id, {
                        type: type,
                        size: size,
                        isEnabled: isEnabled // Pass the enable state
                    }).catch(error => {
                        if (error.message.includes("Could not establish connection. Receiving end does not exist.")) {
                            // Expected for certain Chrome pages, or tabs not fully loaded
                        } else {
                            console.error(`Error sending message to tab ${tab.id}:`, error);
                        }
                    });
                }
            });
        });
    }

    // Function to update UI elements based on highlight state
    function updateUI(isEnabled, size) {
        highlightToggle.checked = isEnabled;
        highlightSizeSlider.disabled = !isEnabled; // Disable slider if highlight is off
        currentSizeDisplay.textContent = `${size}px`;
        // Optionally, make the size display look disabled too
        currentSizeDisplay.style.color = isEnabled ? '#4338ca' : '#9ca3af'; /* Indigo or gray */
    }

    // Load saved highlight state and size from storage
    chrome.storage.local.get(['highlightSize', 'highlightEnabled'], function(result) {
        const savedSize = result.highlightSize || 32;
        const savedEnabled = result.highlightEnabled !== undefined ? result.highlightEnabled : true; // Default to enabled

        updateUI(savedEnabled, savedSize);
        highlightSizeSlider.value = savedSize; // Set slider value even if disabled

        // On load, send initial state to content script
        sendMessageToContent('updateHighlightState', savedSize, savedEnabled);
    });

    // Event listener for slider changes
    highlightSizeSlider.addEventListener('input', function() {
        const newSize = parseInt(this.value, 10);
        currentSizeDisplay.textContent = `${newSize}px`;
        // Save only size; enabled state is handled by toggle
        chrome.storage.local.set({highlightSize: newSize});
        // Send message to content script to update size
        sendMessageToContent('updateHighlightSize', newSize, highlightToggle.checked);
    });

    // Event listener for toggle switch changes
    highlightToggle.addEventListener('change', function() {
        const isEnabled = this.checked;
        const currentSize = parseInt(highlightSizeSlider.value, 10); // Get current slider value
        
        // Save the new enabled state
        chrome.storage.local.set({highlightEnabled: isEnabled});

        updateUI(isEnabled, currentSize); // Update UI immediately

        // Send message to content script to update state
        sendMessageToContent('updateHighlightState', currentSize, isEnabled);
    });
});
